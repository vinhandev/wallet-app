//
//  CallAppSDK.h
//  CallAppSDK
//
//  Created by Tien Nguyen on 3/7/19.
//  Copyright © 2019 Tien Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CallAppSDK.
FOUNDATION_EXPORT double CallAppSDKVersionNumber;

//! Project version string for CallAppSDK.
FOUNDATION_EXPORT const unsigned char CallAppSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CallAppSDK/PublicHeader.h>


