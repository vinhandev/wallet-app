#import <React/RCTEventEmitter.h>
#import <React/RCTBridgeModule.h>

@interface VnpayMerchant : RCTEventEmitter<RCTBridgeModule>

@end

